As world finance an banking representatives met in Washington, the economic news continued to be bleak.
IMF officials had predicted had predicted a banner year, but stocks continued to slide worldwide and the DOW probably would record its worst third quarter loss in eight years.
Russia and Ukraine have been especially hard hit by the crisis.
In Russia, Prime Minister Primakov had no plan to solve the problem as the economy continued to Suffer.
Postal service was threatened as the Post Office could not pay its bills.
President Kuchma of Ukraine called for changes in market reform even as the Parliament turned down a bill to restore lost savings.
