Budget negotiations between the White House and House Republicans were delayed on several issues.
At issue were provisions that included requiring Federal Health Insurance providers to provide contraceptives to women as Well as a provision to build a road across a wildlife preserve in Alaska.
The contraceptive issue faced an uncertain future while Clinton likely will veto the road.
There is disagreement also on how to spend the funding on education.
This year's budget discussions also have been hampered because it is the first time since budget procedures were established in 1974 that there has been a surplus, preventing agreement on a budget resolution.
