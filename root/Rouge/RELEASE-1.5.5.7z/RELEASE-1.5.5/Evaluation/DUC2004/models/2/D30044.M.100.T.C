The leader of the Kurdish rebel group fighting for autonomy in southeast Turkey, Abdullah Ocalan, was arrested at Rome's international airport on Thursday.
The arrest set off a wave of protests throughout Europe as Kurdish groups in Italy, Romania, Germany, Austria rallied in support of Ocalan.
The support ranged from a one-day shutdown of business in Romania to a hunger strike in Rome.
In Turkey, Kurdish inmates took an Italian prisoner hostage in an effort to get Italy to extradite Ocalan.
Italy's leftist Prime Minister was being pressured to grant Ocalan asylum.
