At least 60 teenagers were killed and another 160 were injured in a dance hall fire in Goteborg, Sweden, Sweden's second largest city.
The fire was the worst in Sweden's modern history.
At least 400 teenagers, attending a Halloween dance, were crammed into a facility meant to hold 150.
The dance attendees were mostly immigrant children from representing 19 nationalities, including Somalia, Ethiopia, Iraq, Iran and former Yugoslavia.
The cause of the fire, which quickly engulfed the two-story brick building is unknown as investigators continue to probe the ruins.
Emergency help was delayed by about three minutes because of language difficulties.
