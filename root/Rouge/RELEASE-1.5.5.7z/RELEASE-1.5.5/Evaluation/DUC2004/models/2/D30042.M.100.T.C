On the eve of the 10th anniversary of the 1988 downing of Pan Am 103 over Lockerbie, Scotland, there is hope that the Libya suspects might soon be brought to trial.
UN General Secretary Kofi Annan has met with Libyan officials and an agreement in principle has been reached on the need for a trial.
Libya seeks assurances that the trial will not be politicized.
Libya has been under a UN flight ban since 1992 in an effort to get them to turn over the suspected bombers for trial by Scottish authorities.
The citizens of Lockerbie marked the anniversary of the bombing with a memorial service.
