The Truth and Reconciliation Commission, which was established to look into the human rights violations committed during the long struggle against white rule, released its final report.
In what has been described as one of the most complete reports of its kind, the commission blames most of the atrocities on the former South African government.
The ANC also came under fire for committing some atrocities during the struggle.
Nelson Mandella's ex-wife, Winnie could be prosecuted for the part she played in such violations.
Missing from the report was De Klerk, who threatened to sue if he was mentioned in connection with the atrocities.
