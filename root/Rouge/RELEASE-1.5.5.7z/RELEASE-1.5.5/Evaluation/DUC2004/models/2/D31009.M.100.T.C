Following charges that he interfered in a privatization contract and helped a businessman with mob ties, Turkish Prime Minister Mesut Yilmaz was forced to resign.
President Demeril asked Bulent Ecevit, former three-time prime minister from the 1970s and champion of Turkish Cypriot rights, to form a new government.
After three weeks, Ecevit was unable to secure the support of the Center-Right Party.
At issue was the participation of the Islamic Virtue Part in the secular government, Ecevit returned his mandate and Demeril named Valim Erez as prime minister designate.
Erez was in talks with the Virtue Party over possible cabinet seats.
