In a move considered unthinkable a few years ago, Exxon Corp. and Mobile Corp, have entered into negotiations which could result in a merger of the two companies.
Such a merger, should it occur, would form the world's largest oil company and the largest U.S. company, placing it above Wal-Mart.
The merger, and talks like it among other oil companies, is being prompted By low petroleum prices and high production costs.
Talks of a merger have sent the price of stocks of both companies soaring.
The merger could prompt anti-trust action and the merging companies would have to divest themselves of some interests.
Mobile workers fear a merger will cost them jobs.
