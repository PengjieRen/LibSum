The human toll of tropical storms has been great in recent years.
Seven storms have hit the Philippines.
In 1989, Typhoons Gordon, Angela, and Dan killed a total of 178.
In 1990, Typhoon Percy and another typhoon killed 44, while Tropical Storm Ted and another storm killed 18.
Cyclones in Bangladesh killed 125,730 in May 1991, 140,000 in August 1991, and killed 110 and injured over 5,000 in May 1994.
In 1989 in China, Typhoon Vera killed 48 and injured 190, and Typhoon Yancy killed 216.
In 1994 in Taiwan, one typhoon killed at least three, and Typhoon Seth killed one.
In the US in 1989, Tropical Storm Allison killed 13, Hurricane Gabrielle killed at least six, Hurricane Hugo killed 29, and Hurricane Jerry killed two.
Hurricane Lili and Tropical Storm Marco killed nine in1990.
Hurricane Andrew killed at least 16 and injured about 100 in 1992 and 20 died in Tropical Storm Alberto in1994.
Andrew killed three in the Bahamas.
In the Caribbean, Hugo killed at least 25 and injured hundreds in 1989, and Tropical Storms Klaus and Cindy, combined killed six and injured ten in 1990.
Hurricane Joan killed over 116 in Nicaragua in1988, and Hurricane Calvin killed at least 19 in Mexico in 1993.
A Soviet Far East typhoon killed seven in 1989.
Typhoon Flo killed at least 15 in Japan in1990.
Tropical Storm Ed killed at least 10 in Vietnam in 1990.
In 1993, Venezuela's Tropical Storm Bret killed over 300 and injured hundreds more.
