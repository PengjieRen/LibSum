Dogs are well-established partners in law enforcement.
Their extraordinary noses make them superior to any man or man-made device in detecting substances such as narcotics, explosives, flammable liquids, and agricultural contraband.
They are excellent at tracking suspects and missing persons, and add muscle to law enforcement personnel in controlling crowds.
Border guards us dogs to sniff narcotics, explosives, contraband, and even hiding or smuggled people, trying to illegally pass through borders.
Dogs are used in airports for the same activities, inspecting airplanes, passengers and luggage.
The US Customs Service also uses dogs to inspect boats for the same things.
London police use dogs to monitor potential IRA terrorist activity and to check vehicles at roadblocks for weapons, explosives, and suspects.
In Europe, police dogs are used for riot and crowd control, including the control of soccer hooligans at international games.
US police and military police use dogs to sniff for arson, narcotics, and explosives.
On patrol, police dogs track, control, apprehend, or attack suspects and are used to investigate crime scenes.
They assist in searching for missing persons.
Bomb-sniffing dogs assist the US Secret Service.
Prison guards use German shepherds for crowd control and to track escaped convicts.
When not on patrol, many police dogs perform public relations duties in schools, senior citizen homes and hospitals.
German shepherds, Belgian malinois, and Labrador retrievers are best for narcotics and patrol duties.
Other breeds which assist law enforcement include Airedale-Belgian malinois mixes, Rottweilers, beagles, English cocker spaniels, beagle-spaniel mixes, and mongrels.
