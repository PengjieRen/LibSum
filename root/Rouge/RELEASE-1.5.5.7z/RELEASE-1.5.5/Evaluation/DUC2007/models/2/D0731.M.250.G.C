In 1997, Linda Tripp and Monica Lewinsky worked in the White House.
Monica confided in the older Linda and looked to her for help and advice.
Linda recorded 40 telephone conversations totalling 20 hours with Monica, 38 on her own and 2 while working with the FBI.
On those tapes, Monica spoke of her affair with President Clinton and, allegedly, about attempts to cover it up.
In January 1998, Linda brought the tapes to independent counsel Kenneth Starr who was conducting an ongoing investigation of Clinton and told him that Monica had encouraged her to lie under oath.
Ms. Tripp was granted immunity by the special prosecutor and testified before a grand jury in July 1998 which led to congressional impeachment hearings.
Linda claimed that New York literary agent Lucianne Goldberg suggested that she pass the tapes to Kenneth Starr and also that she talk to lawyers representing Paula Jones, the woman suing Clinton for sexual harassment.
It was widely suggested that Linda's motivation for revealing the tapes was the prospect of a book deal.
She was already discussing a story with Goldberg: an account of her last moments with Vince Foster, deputy White House counsel who shot himself in 1993.
Linda was the last co-worker to see him alive.
Ms Tripp was indicted in July 1999 and charged with illegally taping a December 1997 phone conversation with Monica and for illegally directing her attorney to disclose its contents to Newsweek magazine.
The case was dismissed for insufficient evidence.
