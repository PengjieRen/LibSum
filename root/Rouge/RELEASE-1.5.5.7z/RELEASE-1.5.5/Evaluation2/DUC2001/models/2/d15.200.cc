Tuberculosis is a highly communicable disease .
Its morbidity rate was declining from the 1950 s until the early 1980 s .
The trend was then reversed and by the mid - 1980 s it was increasing rapidly .
By 1990 it was killing three million a year , and was identified as the world 's deadliest infectious disease .
The incidence of tuberculosis varies widely from area to area .
It was running rampant in sub - Saharan Africa , and was increasing in Latin America and Southeast Asia .
In 1989 , within the United States , there was an increase of five percent over the previous year .
Wyoming reported no new cases , but New Jersey had an increase of 35 percent .
The AIDS connection is the single most important factor in the tuberculosis epidemic .
This is true everywhere , but especially so in Africa where AIDS is unchecked .
Millions of people carry the latent tuberculosis bacterium in their bodies and never become ill unless their immune systems lose the capability to fight off the disease .
This happens to AIDS patients .
They develop tuberculosis , and unlike AIDS , it is easily transmitted through the air .
Prisoners are three times more likely to have tuberculosis than are non - prisoners .
Modern airtight office buildings , housing large staffs and often providing poor ventilation , are sources of tuberculosis .
