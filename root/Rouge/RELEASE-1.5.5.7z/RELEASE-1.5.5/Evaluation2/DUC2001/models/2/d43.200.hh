De Beers Consolidated Mines of South Africa controls 80 0f the world 's uncut diamond market through its London - based Central Selling Organization .
The cartel has sales agreements with mines and offers diamonds to select dealers .
De Beers was formed in 1888 by Cecil Rhodes and has been controlled since 1929 by the Oppenheimer family .
De Beers has kept the diamond market stable by controlling supply .
It has bought up diamonds that flooded the market , discouraged banks from lending to diamond speculators , dumped diamonds to force producers into sales agreements , imposed quotas on producers when sales were declining , and revived the industry by putting big money into promotion .
De Beers has maintained its own production by opening a new mine and extending the life of two others through underground mining .
Innovations have included automated processing and bussing workers in daily from their homes .
Desire for greater control of their countries ' wealth has caused African nations to demand better terms .
In 1990 De Beers moved half its interests to Switzerland .
After the breakup of the Soviet Union , unofficial diamond exports were rumored and De Beers signed a new sales agreement with the republic of Yukutia .
The US remains the largest diamond market , followed by Japan .
