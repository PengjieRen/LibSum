In March 1988 economic decline increased friction between liberal , rich Slovenia and hardline communist Serbia .
After Slovenia arrested pro - Serbian demonstrators in December 1989 , Serbia severed political and economic contact .
In June 1990 a new government in Slovenia approved a plan for Slovenian sovereignty within a Yugoslav confederation .
Croatia took similar action .
Fighting erupted after Serbian president Milosevic delayed the 1991 installation of a Croatian federal president and both Slovenia and federal forces prepared for further hostilities .
In mid - June an EC - brokered cease - fire called for installation of the president and a three - month delay in independence moves .
More fighting followed Slovenia 's and Croatia 's June 25 , 1991 secession from Yugoslavia .
Problems facing Slovenia 's efforts to become a market - oriented democracy included funds still frozen by Yugoslavia in March 1992 and the need to establish new foreign credit and gain admission to the IMF and World Bank .
By May 1992 inflation was under control .
Slovenia sought new markets to replace those lost in Yugoslavia .
By March 1993 privatization had begun , wages had dropped and productivity rose as Slovenia worked to stay competitive without cheap Serbian raw materials .
In February 1994 Slovenia approached Belgrade regarding normalization of relations , but Serbia insisted Slovenia end its anti - Serbian campaign first .
